package com.generation.vhfc.myappjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo04jwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
