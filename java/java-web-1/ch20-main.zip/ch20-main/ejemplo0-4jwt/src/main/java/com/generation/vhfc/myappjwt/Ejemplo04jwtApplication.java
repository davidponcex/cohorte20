package com.generation.vhfc.myappjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo04jwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo04jwtApplication.class, args);
	}

}
