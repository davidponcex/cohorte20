package com.generation.vhfc.myappjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiUsuarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
